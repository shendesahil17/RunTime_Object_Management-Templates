
#include <iostream>
#include"Book.h"
#include"player.h"
using namespace std;

template<class T>
class Node

{
    T data;
    Node *next;

public:
    Node(T);
    void setdata(T);
    bool updatedata();
    void setnext(Node *);
    T& getdata();
    Node *getnext();
    
};