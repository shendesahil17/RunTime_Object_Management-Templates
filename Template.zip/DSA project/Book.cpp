#include "Book.h"
using namespace std;

char idTitle[10] = "ID", nameTitle[10] = "Name", authorTitle[10] = "Author", ratingTitle[10] = "Rating", priceTitle[10] = "Price";

//	Default Constructor
Book ::Book()
{
	this->number = 0;
	strcpy(this->name, "N/A");
	strcpy(this->author, "N/A");
	this->price = 0;
	this->rating = 0;
}
// Parameterised Constructor
Book ::Book(int id, char *name, char *author, double price, double rating)
{
	this->number = id;
	strcpy(this->name, name);
	strcpy(this->author, author);
	this->price = price;
	this->rating = rating;
}
// Seters / Mutators
void Book ::setnumber(int id)
{
	this->number = id;
}
void Book ::setname(char *name)
{
	strcpy(this->name, name);
}
void Book ::setauthor(char *author)
{
	strcpy(this->author, author);
}
void Book ::setprice(double price)
{
	this->price = price;
}
void Book ::setrating(double rating)
{
	this->rating = rating;
}

// Geters / Accessors
int Book ::getnumber()
{
	return this->number;
}
char *Book ::getname()
{
	return this->name;
}
char *Book ::getauthor()
{
	return this->author;
}
double Book ::getprice()
{
	return this->price;
}
double Book ::getrating()
{
	return this->rating;
}

bool Book::update()
{
	int c;
	cout << "\n--------What You Want To Update---------\n";
	cout << "\t1.Update Book Price \n\t2.Update Book Rating \nEnter Your Choice:- ";
	cin >> c;
	switch (c)
	{
	case 1:
	{
		double price;
		cout << "\nEnter New Book Price:- ";
		cin >> price;
		setprice(price);
		return true;
	}
	case 2:
	{
		double rating;
		cout << "\nEnter New Book Rating:- ";
		cin >> rating;
		setrating(rating);
		return true;
	}
	default:
		cout << "\n\tInvalid Choice!\n";
		return false;
	}
}

void Book ::display()
{
	cout << left << setw(8) << this->number << "| " << left << setw(20) << this->name << "| " << left << setw(20) << this->author << "| " << setw(15) << fixed << setprecision(2) << this->rating << "| " << setw(15) << fixed << setprecision(2) << this->price << "|";
	cout << "\n----------------------------------------------------------------------------------------\n";
}

void tDisplay()
{
	cout << "\n----------------------------------------------------------------------------------------\n";
	cout << left << setw(8) << idTitle << "| " << left << setw(20) << nameTitle << "| " << left << setw(20) << authorTitle << "| " << setw(15) << ratingTitle << "| " << setw(15) << priceTitle << "|";
	cout << "\n----------------------------------------------------------------------------------------\n";
}