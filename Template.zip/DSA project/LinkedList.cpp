#include "LinkedList.h"

template <class T>
LinkedList<T>::LinkedList()
{
	cout<<"constr called";
    this->start = NULL;
    // // ifstream readbook("Book.bin", ios_base::binary);
    ifstream in;
    if (sizeof(T) == sizeof(Book))
        in.open("Book.bin", ios_base::binary);
    else if (sizeof(T) == sizeof(Players))
    
        in.open("Player.bin", ios_base::binary);
    
    else
        in.open("DataFile.bin", ios_base::binary);
    if (in.is_open())
    {
        T d;
        while (!in.eof())
        {
            in.read(reinterpret_cast<char *>(&d), sizeof(T));

            if (!in.eof())
                insertRecordEnd(d);
        }
        in.close();
    }
}

//////////////////////////////////////

template <class T>
bool LinkedList<T>::insertRecordBegining(T data)
{
    Node<T> *temp = new Node<T>(data);
    if (start == NULL)
    {
        this->start = temp;
        return true;
    }
    temp->setnext(this->start);
    this->start = temp;
    return true;
}
//////////////////////////////////////
template <class T>
bool LinkedList<T>::insertRecordEnd(T data)
{
    Node<T> *temp = new Node<T>(data);
    if (this->start == NULL)
    {
        this->start = temp;
        return true;
    }
    Node<T> *p;
    p = this->start;
    while (p->getnext() != NULL)
    {
        p = p->getnext();
    }
    p->setnext(temp);

    return true;
}
//////////////////////////////////////
template <class T>
bool LinkedList<T>::insertRecordPos(T data, int pos)
{
    Node<T> *temp = new Node<T>(data);
    if (this->start == NULL)
    {
        this->start = temp;
        return true;
    }
    else
    {
        Node<T> *p;
        p = this->start;
        int i = 1;
        while (p->getnext() != NULL && i <= pos)
        {
            if (i == pos - 1 || p->getnext() == NULL)
            {
                temp->setnext(p->getnext());
                p->setnext(temp);
                break;
            }
            p = p->getnext();
            i++;
        }
    }
}
//////////////////////////////////////
template <class T>
Node<T> *LinkedList<T>::searchRecord(int number)
{
    if (start == NULL)
        return NULL;
    Node<T> *p = start;
    while (p != NULL)
    {
        if (p->getdata().getnumber() == number)
            return p;
        p = p->getnext();
    }
    return NULL;
}
//////////////////////////////////////
template <class T>
Node<T> *LinkedList<T>::searchRecord(char *name)
{
    if (start == NULL)
        return NULL;
    Node<T> *p = start;
    while (p != NULL)
    {
        if (strcasecmp(p->getdata().getname(), name) == 0)
            return p;
        p = p->getnext();
    }
    return NULL;
}

//////////////////////////////////////
template <class T>
bool LinkedList<T>::deleteFirstRecord(T &d)
{
    if (this->start == NULL)
        return false;
    Node<T> *p = this->start;
    d = this->start->getdata();
    this->start = p->getnext();
    delete p;
    return true;
}

//////////////////////////////////////
template <class T>
bool LinkedList<T>::deleteLastRecord(T &d)
{
    if (this->start == NULL)
        return false;
    if (this->start->getnext() == NULL)
    {
        Node<T> *p = this->start;
        d = this->start->getdata();
        this->start = this->start->getnext();
        delete p;
        return true;
    }

    Node<T> *p = this->start;
    while (p->getnext()->getnext() != NULL)
    {
        p = p->getnext();
    }
    d = p->getnext()->getdata();
    delete p->getnext();
    p->setnext(NULL);
    return true;
}

//////////////////////////////////////
template <class T>
bool LinkedList<T>::deleteRecord(T &d, int number)
{
    if (start == NULL)
        return false;

    Node<T> *q = searchRecord(number);
    if (q != NULL)
    {
        if (q == start)
            return deleteFirstRecord(d);

        if (q->getnext() == NULL)
            return deleteLastRecord(d);

        Node<T> *p = start;
        while (p->getnext() != q)
            p = p->getnext();

        if (p->getnext() == q)
        {
            d = q->getdata();
            p->setnext(q->getnext());
            delete q;
            return true;
        }
    }

    return false;
}

//////////////////////////////////////
template<class T>
bool LinkedList<T>::deleteRecord(T &d, char *name)
{
    if (start == NULL)
        return false;

    Node<T> *q = searchRecord(name);
    if (q != NULL)
    {
        if (q == start)
            return deleteFirstRecord(d);

        if (q->getnext() == NULL)
            return deleteLastRecord(d);

        Node<T> *p = start;
        while (p->getnext() != q)
            p = p->getnext();

        if (p->getnext() == q)
        {
            d = q->getdata();
            p->setnext(q->getnext());
            delete q;
            return true;
        }
    }

    return false;
}

//////////////////////////////////////
template <class T>
bool LinkedList<T>::updateRecord(Node<T> *&data)
{
    return data->getdata().update();
}

//////////////////////////////////////
template <class T>
void LinkedList<T>::display()
{
    if (start == NULL)
    {
        cout << "\n\n\tList is Empty!!\n";
        return;
    }
    Node<T> *p;
    p = this->start;
    // tDisplay();
    while (p != NULL)
    {
        p->getdata().display();
        p = p->getnext();
    }
}

//////////////////////////////////////
template <class T>
LinkedList<T>::~LinkedList()
{
	cout<<"destru called";
    Node<T> *p = this->start;
    ofstream out;
    if (sizeof(T) == sizeof(Book))
        out.open("Book.bin", ios_base::binary);
    else if (sizeof(T) == sizeof(Players))
        out.open("Player.bin", ios_base::binary);
    else
        out.open("DataFile.bin", ios_base::binary);
    if (p != NULL)
    {    
        while (p != NULL)
        {
            out.write((char *)(&(p->getdata())), sizeof(T));
            this->start = p->getnext();
            delete p;
            p = this->start;
        }
        
        out.close();
    }
}