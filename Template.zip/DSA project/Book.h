	using namespace std;
	#include <iomanip>
	#include <iostream>
	#include <stdlib.h>
	#include <string.h>

	class Book
	{
		int number;
		char name[20], author[20];
		double price, rating;

	public:
		//	Default Constructor
		Book();

		// Parameterised Constructor
		Book(int, char *, char *, double, double);

		// Seters / Mutators
		void setnumber(int);
		void setname(char *);
		void setauthor(char *);
		void setprice(double);
		void setrating(double);

		// Geters / Accessors
		int getnumber();
		char *getname();
		char *getauthor();
		double getprice();
		double getrating();

		// Function Declaration
		void display();
		bool update();
	};
	void tDisplay();