#include"Node.cpp"
#include<fstream>

template<class T>
class LinkedList
{

    Node<T> *start;

public: 

    LinkedList();
    ~LinkedList();
    bool insertRecordBegining(T);
    bool insertRecordEnd(T);
    bool insertRecordPos(T, int);
    bool updateRecord(Node<T>*&);
    bool deleteFirstRecord(T &);
    bool deleteLastRecord(T &);
    bool deleteRecord(T &, int );
    bool deleteRecord(T &, char*);
    void display();
    Node<T>* searchRecord(int);
    Node<T>* searchRecord(char*);

  



};