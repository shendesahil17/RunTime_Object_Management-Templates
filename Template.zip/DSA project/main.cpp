#include "LinkedList.cpp"

int main()
{
    int ch;
    do
    {
        cout << "\n------------------------------\n";
        cout << "\t1.Book Management \n\t2.Player Management \n\t0.Save & Exit \nEnter Your Choice:- ";
        cout << "\n------------------------------\n";
        cin >> ch;
        switch (ch)
        {
        case 1:
        {
            int c;
            LinkedList<Book> book;
            do
            {
                cout << "\n------------------------------\n";
                cout << "\t1.Add Book\n\t2.Display Books\n\t3.Search Book\n\t4.Delete Book\n\t5.Update Book Record\n\t0.Exit\nEnter Your Choice:- ";
                cout << "\n------------------------------\n";
	            cin >> c;

                switch (c)
                {
                case 1:
                {
                    int ch;
                    cout << "\n------------------------------\n";
                    cout << "\t1.Insert Data At Begining \n\t2.Insert Data At End \n\t3.Insert Data At Any Position";
                    cout << "\nEnter Your Choice:- ";
                    cout << "\n------------------------------\n";
                    cin >> ch;
                    switch (ch)
                    {
                    case 1:
                    {
                        int id;
                        char name[20], author[20];
                        double price, rating;

                        cout << "Enter Book ID:- ";
                        cin >> id;

                        cout << "Enter Book Name:- ";
                        fflush(stdin);
                        gets(name);

                        cout << "Enter Book Author Name:- ";
                        fflush(stdin);
                        gets(author);

                        cout << "Enter Book Price:- ";
                        cin >> price;

                        cout << "Enter Book Rating:- ";
                        cin >> rating;

                        Book b(id, name, author, price, rating);

                        if (book.insertRecordBegining(b))
                            cout << "\nData Inserted Succesfully!";
                        else
                            cout << "\nData NOT Inserted!";
                        break;
                    }
                    case 2:
                    {
                        int id;
                        char name[20], author[20];
                        double price, rating;

                        cout << "Enter Book ID:- ";
                        cin >> id;

                        cout << "Enter Book Name:- ";
                        fflush(stdin);
                        gets(name);

                        cout << "Enter Book Author Name:- ";
                        fflush(stdin);
                        gets(author);

                        cout << "Enter Book Price:- ";
                        cin >> price;

                        cout << "Enter Book Rating:- ";
                        cin >> rating;

                        Book b(id, name, author, price, rating);

                        if (book.insertRecordEnd(b))
                            cout << "\nData Inserted Succesfully!";
                        else
                            cout << "\nData NOT Inserted!";
                        break;
                    }
                    case 3:
                    {
                        int id, p;
                        char name[20], author[20];
                        double price, rating;

                        cout << "Enter Book ID:- ";
                        cin >> id;

                        cout << "Enter Book Name:- ";
                        fflush(stdin);
                        gets(name);

                        cout << "Enter Book Author Name:- ";
                        fflush(stdin);
                        gets(author);

                        cout << "Enter Book Price:- ";
                        cin >> price;

                        cout << "Enter Book Rating:- ";
                        cin >> rating;

                        cout << "\nEnter Position to Insert Value:- ";
                        cin >> p;

                        Book b(id, name, author, price, rating);

                        if (book.insertRecordPos(b, p))
                            cout << "\nData Inserted Succesfully!";
                        else
                            cout << "\nData NOT Inserted!";
                        break;
                    }
                    default:
                        cout << "\nInvalid Choice!";
                        break;
                    }

                    break;
                }
                case 2:
                {
                    tDisplay();
                    book.display();
                    break;
                }
                case 3:
                {
                    int ch;
                    cout << "\n\t1.Search By Book ID\n\t2.Search By Book Name\nEnter Your Choice:- ";
                    cin >> ch;
                    switch (ch)
                    {
                    case 1:
                    {
                        int id;
                        cout << "\nEnter Book Id:- ";
                        cin >> id;
                        Node<Book> *i = book.searchRecord(id);
                        if (i != NULL)
                        {
                            tDisplay();
                            i->getdata().display();
                        }
                        else
                            cout << "\nBook Set Are Empty or Book Record Not Found";
                        break;
                    }

                    case 2:
                    {
                        char name[20];
                        cout << "\nEnter Book Name:- ";
                        fflush(stdin);
                        gets(name);
                        Node<Book> *i = book.searchRecord(name);
                        if (i != NULL)
                        {
                            tDisplay();
                            i->getdata().display();
                        }
                        else
                            cout << "\nBook Set Are Empty or Book Record Not Found";
                        break;
                    }

                    default:
                        cout << "\nInvalid Choice!";
                        break;
                    }
                    break;
                }
                case 4:
                {
                    int ch;
                    cout << "\n\t1.Delete First Book \n\t2.Delete Last Book \n\t3.Delete Book By Searching \nEnter Your Choice:- ";
                    cin >> ch;
                    switch (ch)
                    {
                    case 1:
                    {
                        Book b;
                        if (book.deleteFirstRecord(b))
                        {
                            tDisplay();
                            b.display();
                            cout << "\nBook Was Deleted Successfully!";
                        }
                        else
                            cout << "\nDelete Operation Failed!";

                        break;
                    }

                    case 2:
                    {
                        Book b;
                        if (book.deleteLastRecord(b))
                        {
                            tDisplay();
                            b.display();
                            cout << "\nBook Was Deleted Successfully!";
                        }
                        else
                            cout << "\nDelete Operation Failed!";

                        break;
                    }
                    case 3:
                    {
                        int c;
                        cout << "\n\t1.Search Book With ID \n\t2.Search Book With Name \nEnter Your Choice:- ";
                        cin >> c;
                        switch (c)
                        {
                        case 1:
                        {
                            int id;
                            cout << "\nEnter Book Id:- ";
                            cin >> id;
                            Book b;
                            if (book.deleteRecord(b, id))
                            {
                                tDisplay();
                                b.display();
                                cout << "\nBook Was Deleted Successfully!\n";
                            }
                            else
                                cout << "\nBook Set Are Empty or Book Record Not Found";
                            break;
                        }

                        case 2:
                        {
                            char name[20];
                            cout << "\nEnter Book Name:- ";
                            fflush(stdin);
                            gets(name);
                            Book b;
                            if (book.deleteRecord(b, name))
                            {
                                tDisplay();
                                b.display();
                                cout << "\nBook Was Deleted Successfully!\n";
                            }
                            else
                                cout << "\nBook Set Are Empty or Book Record Not Found";
                        }

                        default:
                            cout << "\n\tInvalid Choice!\n";
                            break;
                        }
                    }
                    }
                    break;
                }
                case 5:
                {
                    int ch;
                    cout << "\n-------------Search Book For Update----------------\n";
                    cout << "\n\t1.Search Book With ID \n\t2.Search Book With Name \nEnter Your Choice:- ";
                    cin >> ch;
                    switch (ch)
                    {
                    case 1:
                    {
                        int id;
                        cout << "\nEnter Book Id:- ";
                        cin >> id;
                        Node<Book> *i = book.searchRecord(id);
                        if (i != NULL)
                        {
                            tDisplay();
                            i->getdata().display();
                            if (book.updateRecord(i))
                                cout << "\nBook Record Updated Successfully!";
                            else
                                cout << "\nSomething Wents Rong!";
                        }
                        else
                            cout << "\nBook Set Are Empty or Book Record Not Found";
                        break;
                    }

                    case 2:
                    {
                        char name[20];
                        cout << "\nEnter Book Name:- ";
                        fflush(stdin);
                        gets(name);
                        Node<Book> *i = book.searchRecord(name);
                        if (i != NULL)
                        {
                            tDisplay();
                            i->getdata().display();
                            if (book.updateRecord(i))
                                cout << "\nBook Record Updated Successfully!";
                            else
                                cout << "\nSomething Wents Rong!";
                        }
                        else
                            cout << "\nBook Set Are Empty or Book Record Not Found";
                        break;
                    }
                    }
                    break;
                }

                case 0:
                {
                    break;
                }
                default:
                    cout << "\nInvalid Choice!";
                    break;
                }
            } while (c != 0);
            break;
        }
        case 2:
        {
            int c;
            LinkedList<Players> player;
            do
            {
                cout << "\n-------------Select Operation--------------\n";
                cout << "\t1.Add Player\n\t2.Display Players\n\t3.Search Player\n\t4.Delete Player\n\t5.Update Player Record\n\t0.Exit\nEnter Your Choice:- ";
                cin >> c;

                switch (c)
                {
                case 1:
                {
                    int ch;
                    cout << "\n-------------Select Operation--------------\n";
                    cout << "\t1.Insert Data At Begining \n\t2.Insert Data At End \n\t3.Insert Data At Any Position";
                    cout << "\nEnter Your Choice:- ";
                    cin >> ch;
                    switch (ch)
                    {
                    case 1:
                    {
                        int no;
                        char name[20];
                        int matches, wickets, runs;

                        cout << "Enter Jersey No of Player:- ";
                        cin >> no;

                        cout << "Enter Player Name:- ";
                        fflush(stdin);
                        gets(name);

                        cout << "Enter Player Played Matches:- ";
                        cin >> matches;

                        cout << "Enter Player Runs:- ";
                        cin >> runs;

                        cout << "Enter Player Wickets:- ";
                        cin >> wickets;

                        Players p(no, name, matches, runs, wickets);

                        if (player.insertRecordBegining(p))
                            cout << "\nData Inserted Succesfully!";
                        else
                            cout << "\nData NOT Inserted!";
                        break;
                    }
                    case 2:
                    {
                        int no;
                        char name[20];
                        int matches, wickets, runs;

                        cout << "Enter Jersey No of Player:- ";
                        cin >> no;

                        cout << "Enter Player Name:- ";
                        fflush(stdin);
                        gets(name);

                        cout << "Enter Player Played Matches:- ";
                        cin >> matches;

                        cout << "Enter Player Runs:- ";
                        cin >> runs;

                        cout << "Enter Player Wickets:- ";
                        cin >> wickets;

                        Players p(no, name, matches, runs, wickets);

                        if (player.insertRecordEnd(p))
                            cout << "\nData Inserted Succesfully!";
                        else
                            cout << "\nData NOT Inserted!";
                        break;
                    }
                    case 3:
                    {
                        int no, pos;
                        char name[20];
                        int matches, wickets, runs;

                        cout << "Enter Jersey No of Player:- ";
                        cin >> no;

                        cout << "Enter Player Name:- ";
                        fflush(stdin);
                        gets(name);

                        cout << "Enter Player Played Matches:- ";
                        cin >> matches;

                        cout << "Enter Player Runs:- ";
                        cin >> runs;

                        cout << "Enter Player Wickets:- ";
                        cin >> wickets;

                        cout << "\nEnter Position to Insert Record:- ";
                        cin >> pos;

                        Players p(no, name, matches, runs, wickets);

                        if (player.insertRecordPos(p, pos))
                            cout << "\nData Inserted Succesfully!";
                        else
                            cout << "\nData NOT Inserted!";
                        break;
                    }
                    default:
                        cout << "\nInvalid Choice!";
                        break;
                    }

                    break;
                }
                case 2:
                {
                    Extra();
                    player.display();
                    break;
                }
                case 3:
                {
                    int ch;
                    cout << "\n\t1.Search Player By Jeresy Number \n\t2.Search Player By Name \nEnter Your Choice:- ";
                    cin >> ch;
                    switch (ch)
                    {
                    case 1:
                    {
                        int no;
                        cout << "\nEnter Jeresy Number:- ";
                        cin >> no;
                        Node<Players> *i = player.searchRecord(no);
                        if (i != NULL)
                        {
                            Extra();
                            i->getdata().display();
                        }
                        else
                            cout << "\nBook Set Are Empty or Book Record Not Found";
                        break;
                    }

                    case 2:
                    {
                        char name[20];
                        cout << "\nEnter Player Name:- ";
                        fflush(stdin);
                        gets(name);
                        Node<Players> *i = player.searchRecord(name);
                        if (i != NULL)
                        {
                            tDisplay();
                            i->getdata().display();
                        }
                        else
                            cout << "\nBook Set Are Empty or Book Record Not Found";
                        break;
                    }
                    break;
                    }
                    break;
                }
                case 4:
                {
                    int ch;
                    cout << "\n\t1.Delete First Player \n\t2.Delete Last Player \n\t3.Delete Player By Searching \nEnter Your Choice:- ";
                    cin >> ch;
                    switch (ch)
                    {
                    case 1:
                    {
                        Players p;
                        if (player.deleteFirstRecord(p))
                        {
                            Extra();
                            p.display();
                            cout << "\nPlayer Was Deleted Successfully!";
                        }
                        else
                            cout << "\nDelete Operation Failed!";

                        break;
                    }

                    case 2:
                    {
                        Players p;
                        if (player.deleteLastRecord(p))
                        {
                            Extra();
                            p.display();
                            cout << "\nPlayer Was Deleted Successfully!";
                        }
                        else
                            cout << "\nDelete Operation Failed!";

                        break;
                    }
                    case 3:
                    {
                        int c;
                        cout << "\n\t1.Search Player By Jeresy Number \n\t2.Search Player By Name \nEnter Your Choice:- ";
                        cin >> c;
                        switch (c)
                        {
                        case 1:
                        {
                            int no;
                            cout << "\nEnter Player Jeresy Number:- ";
                            cin >> no;
                            Players p;
                            if (player.deleteRecord(p, no))
                            {
                                Extra();
                                p.display();
                                cout << "\nPlayer Record Was Deleted Successfully!\n";
                            }
                            else
                                cout << "\nPlayer Set Are Empty or Player Record Not Found";
                            break;
                        }

                        case 2:
                        {
                            char name[20];
                            cout << "\nEnter Player Name:- ";
                            fflush(stdin);
                            gets(name);
                            Players p;
                            if (player.deleteRecord(p, name))
                            {
                                Extra();
                                p.display();
                                cout << "\nPlayer Record Was Deleted Successfully!\n";
                            }
                            else
                                cout << "\nPlayer Set Are Empty or Player Record Not Found";
                        }

                        default:
                            cout << "\n\tInvalid Choice!\n";
                            break;
                        }
                    }
                    }
                    break;
                }
                case 5:
                {
                    int ch;
                    cout << "\n-------------Search Player For Update----------------\n";
                    cout << "\n\t1.Search Player By Jeresy Number \n\t2.Search Player By Name \nEnter Your Choice:- ";
                    cin >> ch;
                    switch (ch)
                    {
                    case 1:
                    {
                        int no;
                        cout << "\nEnter Player Jeresy Number:- ";
                        cin >> no;
                        Node<Players> *i = player.searchRecord(no);
                        if (i != NULL)
                        {
                            Extra();
                            i->getdata().display();
                            if (player.updateRecord(i))
                                cout << "\nPlayer Record Updated Successfully!";
                            else
                                cout << "\nSomething Wents Rong!";
                        }
                        else
                            cout << "\nPlayer List Are Empty or Player Record Not Found";
                        break;
                    }

                    case 2:
                    {
                        char name[20];
                        cout << "\nEnter Player Name:- ";
                        fflush(stdin);
                        gets(name);
                        Node<Players> *i = player.searchRecord(name);
                        if (i != NULL)
                        {
                            Extra();
                            i->getdata().display();
                            if (player.updateRecord(i))
                                cout << "\nPlayer Record Updated Successfully!";
                            else
                                cout << "\nSomething Wents Rong!";
                        }
                        else
                            cout << "\nPlayer Set Are Empty or Player Record Not Found";
                        break;
                    }
                    }
                    break;
           
                }

                case 0:
                {
                    break;
                }
                default:
                    cout << "\nInvalid Choice!";
                    break;
                }
            } while (c != 0);
            break;
        }
        }
    } while (ch != 0);
}