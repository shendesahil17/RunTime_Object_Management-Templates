 
#include "Node.h"


template<class T>
Node<T>::Node(T data)
{
    this->data=data;
    this->next = NULL;
}
//////////////////////////////////////
template<class T>
void Node<T>::setdata(T d)
{
    this->data=d;
}
//////////////////////////////////////
template<class T>
void Node<T>::setnext(Node<T> *n)
{
    this->next = n;
}
//////////////////////////////////////
template<class T>
T& Node<T>::getdata()
{
    return this->data;
}
//////////////////////////////////////
template<class T>
Node<T> *Node<T>::getnext()
{
    return this->next;
}